<?php return array (
  'create-bio' => 'App\\Http\\Livewire\\CreateBio',
  'create-link' => 'App\\Http\\Livewire\\CreateLink',
  'create-project' => 'App\\Http\\Livewire\\CreateProject',
  'create-skill' => 'App\\Http\\Livewire\\CreateSkill',
  'edit-bio' => 'App\\Http\\Livewire\\EditBio',
  'links' => 'App\\Http\\Livewire\\Links',
  'list-project' => 'App\\Http\\Livewire\\ListProject',
  'list-skills' => 'App\\Http\\Livewire\\ListSkills',
  'project-component' => 'App\\Http\\Livewire\\ProjectComponent',
  'show-project-front' => 'App\\Http\\Livewire\\ShowProjectFront',
  'show-skills' => 'App\\Http\\Livewire\\ShowSkills',
);