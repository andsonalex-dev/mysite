<?php

namespace App\Http\Livewire;

use Livewire\Component;

class EditBio extends Component
{
    public function render()
    {
        return view('livewire.edit-bio');
    }
}
