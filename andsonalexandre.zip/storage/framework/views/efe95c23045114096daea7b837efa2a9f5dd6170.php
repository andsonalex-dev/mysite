
				<!-- Header -->
                <header id="header" class="alt">
                    <a href="index.html" class="logo"><strong>Andson</strong> <span>Alexandre</span></a>
                    <nav>
                        <a href="#menu">Menu</a>
                    </nav>
                </header>

            <!-- Menu -->
                <nav id="menu">
                    <ul class="links">
                        <li><a href="index.html">Home</a></li>
                        <li><a href="#">Social Media</a></li>
                        <li><a href="#">Skills</a></li>
                        <li><a href="#">Trabalhos</a></li>
                    </ul>
                    <ul class="actions stacked">
                        <li><a href="/dashboard" class="button fit">Log In</a></li>
                    </ul>
                </nav>
<?php /**PATH E:\xampp2\htdocs\andsonalexandre\resources\views/components/navbarfront.blade.php ENDPATH**/ ?>