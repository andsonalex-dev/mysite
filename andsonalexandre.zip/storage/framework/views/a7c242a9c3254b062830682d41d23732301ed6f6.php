<span class="mb-2 font-bold text-white uppercase">Minhas redes sociais</span>
<?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $type = Str::lower($link->type);
?>
<span class="my-2">
    <a href="<?php echo e($link->url); ?>" class="text-green-600 hover:text-green-800" >
        <i class="fab fa-<?php echo $type; ?> text-lg"> <span class="text-xl" style="font-family: 'Source Sans Pro', sans-serif; "><?php echo e($link->type); ?></span> </i>
    </a>
</span>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH E:\xampp2\htdocs\andsonalexandre\resources\views/livewire/links.blade.php ENDPATH**/ ?>