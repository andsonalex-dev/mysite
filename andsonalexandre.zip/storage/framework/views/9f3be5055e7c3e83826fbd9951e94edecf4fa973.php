<h1>Chegou aqui!</h1>
<?php /**PATH E:\xampp2\htdocs\andsonalexandre\resources\views/showprojects.blade.php ENDPATH**/ ?>