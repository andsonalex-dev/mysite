<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header'); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="pt-4 mt-2 overflow-hidden bg-white shadow-xl sm:rounded-lg">

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('list-project')->html();
} elseif ($_instance->childHasBeenRendered('hst8ZUU')) {
    $componentId = $_instance->getRenderedChildComponentId('hst8ZUU');
    $componentTag = $_instance->getRenderedChildComponentTagName('hst8ZUU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hst8ZUU');
} else {
    $response = \Livewire\Livewire::mount('list-project');
    $html = $response->html();
    $_instance->logRenderedChild('hst8ZUU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <div class="pt-4 mt-2 overflow-hidden bg-white shadow-xl sm:rounded-lg">

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-skill')->html();
} elseif ($_instance->childHasBeenRendered('kZUISt6')) {
    $componentId = $_instance->getRenderedChildComponentId('kZUISt6');
    $componentTag = $_instance->getRenderedChildComponentTagName('kZUISt6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kZUISt6');
} else {
    $response = \Livewire\Livewire::mount('create-skill');
    $html = $response->html();
    $_instance->logRenderedChild('kZUISt6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
            <div class="pt-4 mt-2 overflow-hidden bg-white shadow-xl sm:rounded-lg">

                <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('list-skills')->html();
} elseif ($_instance->childHasBeenRendered('pAOTwHJ')) {
    $componentId = $_instance->getRenderedChildComponentId('pAOTwHJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('pAOTwHJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pAOTwHJ');
} else {
    $response = \Livewire\Livewire::mount('list-skills');
    $html = $response->html();
    $_instance->logRenderedChild('pAOTwHJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH E:\xampp2\htdocs\andsonalexandre\resources\views/dashboard.blade.php ENDPATH**/ ?>